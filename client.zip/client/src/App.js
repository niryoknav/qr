import { Routes,Route } from 'react-router-dom';
import './App.css';
import Layout from './components/Layout';
import Order from './pages/Order'
import Cart from './pages/Cart';
import { UserContextProvider } from './components/UserContext';
import CartOrders from './components/CartOrders';
import AdminOrder from './pages/AdminOrder';
import AddMenu from './pages/AddMenu';

function App() {
  return (
    <UserContextProvider>
    {/* <CartOrders/> */}
      <Routes>
        <Route path='/' element={<Layout/>}>
          <Route path='/menu' element={<Order/>}/>
          <Route path='/cart' element={<Cart/>}/>
        </Route>
        <Route path='/admin/order' element={<AdminOrder/>}/>
        <Route path='/admin/addMenu' element={<AddMenu/>}/>
      </Routes>

    </UserContextProvider>
  );
}

export default App;
