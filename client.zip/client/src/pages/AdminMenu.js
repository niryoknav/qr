import React, { useState,useEffect } from 'react'

const AdminMenu = () => {
    const [menus,setMenus]=useState([])
    const getMenu=async()=>{
        const res=await fetch('http://localhost:2003/getmenu',{
          method:'GET',
          headers:{'Content-type':'application/json'},
        })
        res.json().then(menus=>{
         setMenus(menus)
      })
      }
      const changeStatus=async(id)=>{
        const res=await fetch('http://localhost:2003/stockstatus/'+id,{
            method:'PUT',
            headers:{'Content-type':'application/json'},
            body:JSON.stringify({status:"out of stock"})
        })
        if(res.ok){
            alert('updated')
        }
        window.location.reload()
      }
      useEffect(()=>{
        getMenu()
      },[])
  return (
    <div>
        {menus.map(menu=>(
            <div>
                <div>{menu.type}</div>
                <div>{menu.name}</div>
                <div>{menu.des}</div>
                <div>{menu.price}</div>
                <div>{menu.status}</div>
                <div><button onClick={()=>changeStatus(menu._id)}>Out of stock</button></div>
                </div>
        ))}
    </div>
  )
}

export default AdminMenu