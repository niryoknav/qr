import React from 'react'
import { useState } from 'react'
import AdminMenu from './AdminMenu'
const AddMenu = () => {
    const [name,setName]=useState('')
    const [type,setType]=useState('')
    const [price,setPrice]=useState('')
    const [des,setDes]=useState('')
    const [showMenu,setShowMenu]=useState(false)
    const addItem=async()=>{
        const res=await fetch('http://localhost:2003/additem',{
            method:'POST',
            headers:{'Content-type':'application/json'},
            body:JSON.stringify({name,type,price,des,status:"available"})
        })
        if(res.ok){
            alert('added item')
        }
    }
  return (
    <div className="text-center">
        <div>

        <div><label>Type : </label><input className="border-2" onChange={(e)=>setType(e.target.value)} type='text'/></div>
        <div><label>Name : </label><input className="border-2" onChange={(e)=>setName(e.target.value)} type='text'/></div>
        <div><label>Price : </label><input className="border-2" onChange={(e)=>setPrice(e.target.value)} type='text'/></div>
        <div><label>Description : </label><input className="border-2" onChange={(e)=>setDes(e.target.value)} type='text'/></div>
        <div className="text-center"><button onClick={addItem} className="p-2 px-5 rounded-xl border-2">Add</button></div>
        </div>
        <div>
            <button onClick={(e)=>setShowMenu(!showMenu)}>Show Menu</button>
            {showMenu&&<AdminMenu/>}
        </div>
    </div>
  )
}

export default AddMenu