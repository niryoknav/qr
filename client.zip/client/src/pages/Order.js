import React, { useContext, useEffect, useState } from 'react'
import {menu} from '../components/menu'
import SingleItem from '../components/SingleItem'
import Cart from './Cart'
import { UserContext } from '../components/UserContext'
import { Link } from 'react-router-dom'
const Order = () => {
  const [menus,setMenus]=useState([])
  const{items,setItems}=useContext(UserContext)
  const [open,setOpen]=useState(false)
  const getMenu=async()=>{
    const res=await fetch('http://localhost:2003/getmenu',{
      method:'GET',
      headers:{'Content-type':'application/json'},
    })
    res.json().then(menus=>{
     setMenus(menus)
  })
  }
  useEffect(()=>{
    getMenu()
  },[])
  const addItem=(item)=>{
    const isPresent=items.find((o)=>o.name===item.name)
    if(!isPresent){
      setItems(items=>[...items,item])
    }
    // console.log(items)
}
const removeItem=(item)=>{
  setItems(items.filter((item1)=> item1.name!==item))
  // console.log(items)
}
// const unique = [...new Set(menus.map(item => item.type))];
// console.log(unique)

  return (
    <div className="">
      <div className="mx-5">
    
      {menus.map((menu)=>(
        

          <div className="flex border-2 my-5 w-fit mx-auto" key={menu.index}>
          <SingleItem {...menu}/>
          <div className="text-center mx-2 my-16"><button onClick={()=>{
            addItem({name:menu.name,price:menu.price,quantity:0})
          }} className="border-2 p-2 px-5 rounded-xl">Add</button></div>
          <div className="text-center mx-2 my-16 "><button onClick={()=>{
            removeItem(menu.name)
          }} className="border-2 p-2 px-5 rounded-xl">Remove</button></div>
          </div>
        
              
      ))}
    
      </div>
      {items.length>0&&
      <div className=" text-center fixed bottom-0 h-20 w-full bg-black text-white py-4 text-2xl">
        {items.length} Items added
        <button className="mx-5 border-2 p-2 px-6 rounded-xl text-lg"><Link to='/cart'>Next</Link></button>
      </div>
      }
      
    </div>
  )
}

export default Order