import React, { useContext, useEffect,useState } from 'react'
import { UserContext } from '../components/UserContext'
import CartOrders from '../components/CartOrders'

const Cart = () => {
   const {items,totalPrice,setTotalPrice}=useContext(UserContext)
   const [name,setName]=useState('')
   const [table,setTable]=useState('')
   const [mobile,setMobile]=useState('')
    useEffect(()=>{
        if(totalPrice>0){
            setTotalPrice(0)
        }
    },[])
    const handleSubmit=async()=>{
        const res=await fetch('http://localhost:2003/order',{
            method:'POST',
            headers:{'Content-type':'application/json'},
            body:JSON.stringify({items,name,table,mobile,totalPrice,status:"ordered"})
        })
        if(res.ok){
            alert('order placed')
        }
    }
  return (
    <div className="">
        <div>

       {items.map(item=>(
           <CartOrders itemDet={item} count={0}/>
           ))}
           </div>
           <div className=" border-2 w-fit mx-auto p-5">Total Amount : Rs. {totalPrice}</div>
           <div id="form" className="text-center my-5">
            <div className="my-5"><label>Name : </label><input onChange={(e)=>setName(e.target.value)} type='text' className="border-2" /></div>
            <div className="my-5"><label>Table No : </label><input onChange={(e)=>setTable(e.target.value)} type='text' maxLength={2} className="border-2" /></div>
            <div className="my-5"><label>Mobile No : </label><input onChange={(e)=>setMobile(e.target.value)} type='text' maxLength={10} className="border-2" /></div>
            <div className="text-center"><button onClick={handleSubmit} className="border-2 p-2 px-5 rounded-xl">Submit</button></div>
           </div>
    </div>
  )
}

export default Cart