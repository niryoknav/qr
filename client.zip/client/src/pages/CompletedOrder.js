import React, { useEffect, useState } from 'react'
import {format} from 'date-fns'

const CompletedOrder = () => {
    const [orders,setOrders]=useState([])
    const getOrders=async()=>{
        await fetch('http://localhost:2003/showorders',{
            method:'GET',
            headers:{'Content-type':'application/json'},
        }).then(res=>res.json().then(orders=>setOrders(orders.filter((order)=>order.status==='completed'))))
        // setOrders(orders.filter(order=>order.status==='completed'))
    }
    // console.log(orders)
    useEffect(()=>{
        getOrders()
    },[])
  return (
    <div>
        {orders.map((order)=>(
            <div className="border-2 w-fit m-5 mx-auto p-5">
            <div>Name : {order.name}</div>
            <div>Table No. : {order.table}</div>
            <div>Amount : {order.amount}</div>
            Dish :
            <div className="">{order.orders.map(order=>(
                <div className="flex">
                <div className="mx-5"> {order.name}</div>
                <div> {order.quantity}</div>
                </div>
            ))}</div>
            <div>Mobile No. : {order.mobile}</div>
            <div>Status : {order.status}</div>
            <div>Time : {format(new Date(order.createdAt),'MMM d,yyyy hh:mm')}</div>
            </div>
        ))}
    </div>
  )
}

export default CompletedOrder