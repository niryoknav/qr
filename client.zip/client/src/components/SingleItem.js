
import React from 'react'
import { useState } from 'react'
import Footer from './Footer'

const SingleItem = (menu) => {
  return (
    <div className="my-5 p-2 ">
        <div className="flex">
        <div>

        <div className="text-2xl font-extrabold">{menu.name}</div>
        <div>{menu.des}</div>
        <div>Rs. {menu.price}</div>
        </div>
        </div>
        
    </div>
  )
}

export default SingleItem