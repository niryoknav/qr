export const menu=[
    {
        type:"burger",
        name:"Chicken burger1",
        des:"chicken,bun,cheese",
        price:"170",
    },
    {
        type:"burger",
        name:"Chicken burger2",
        des:"chicken,bun,cheese",
        price:"170",
    },
    {
        type:"burger",
        name:"Chicken burger3",
        des:"chicken,bun,cheese",
        price:"170",
    },
    {
        type:"burger",
        name:"Chicken burger4",
        des:"chicken,bun,cheese",
        price:"170",
    },
    {
        type:"burger",
        name:"Chicken burger5",
        des:"chicken,bun,cheese",
        price:"170",
    },
    {
        type:"burger",
        name:"Chicken burger6",
        des:"chicken,bun,cheese",
        price:"170",
    },
]