import React from 'react'

const Header = () => {
  return (
    <div className="bg-black">
      <div className="text-center text-white h-20">Orders </div>
    </div>
  )
}

export default Header