import React from 'react'

const Footer = () => {
  return (
    <div className="h-32 w-full static bottom-0  bg-red-500 text-white">Footer</div>
  )
}

export default Footer